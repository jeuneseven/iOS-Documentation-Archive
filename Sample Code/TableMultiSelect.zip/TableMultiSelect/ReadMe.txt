# TableMultiSelect

"TableMultiSelect" demonstrates the use of multiple selection of table cells in UITableView, in particular using multiple selection to delete one or more items.

----
Copyright (C) 2011-2013 Apple Inc. All rights reserved.
