/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The presented view controller for the Swipe demo.
 */

@import UIKit;

@interface AAPLSwipeSecondViewController : UIViewController

@end
