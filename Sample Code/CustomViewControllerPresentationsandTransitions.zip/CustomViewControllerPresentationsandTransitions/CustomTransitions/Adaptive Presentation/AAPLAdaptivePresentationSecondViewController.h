/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The second view controller for the Adaptive Presentation demo.
 */

@import UIKit;

@interface AAPLAdaptivePresentationSecondViewController : UIViewController
@end
