/*
Copyright (C) 2015 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
Custom UICollectionViewLayout to represent Circle Layout design.
*/

@interface CircleLayout : UICollectionViewLayout

@end
