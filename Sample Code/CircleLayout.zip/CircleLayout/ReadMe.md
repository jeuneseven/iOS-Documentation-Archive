# CircleLayout

## Description
+ Shows how to use a collection view to arrange views on a circle and use custom animations when inserting and removing items.

## Build Requirements
+ iOS 8.0 SDK or later

## Runtime Requirements
+ iOS 8.0 or later


Copyright (C) 2015-2012 Apple Inc. All rights reserved.
