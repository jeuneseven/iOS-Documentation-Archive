/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Demonstrates using a custom back button image with no chevron and no text.
 */

@import UIKit;

@interface CustomBackButtonViewController : UITableViewController
@end
