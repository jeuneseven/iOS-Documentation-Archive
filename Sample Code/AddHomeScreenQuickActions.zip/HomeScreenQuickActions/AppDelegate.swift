/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The application delegate.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    /// Temporary variable to hold a shortcut item from the launching or activation of the app.
    var shortcutItemToProcess: UIApplicationShortcutItem?

    // MARK: - Application life cycle

    /// - Tag: DidFinishLaunching
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        // If launchOptions contains the appropriate launch options key, a Home screen quick action
        // is responsible for launching the app. Store the action for processing once the app has
        // completed initialization.
        if let shortcutItem = launchOptions?[UIApplication.LaunchOptionsKey.shortcutItem] as? UIApplicationShortcutItem {
            shortcutItemToProcess = shortcutItem
        }

        return true
    }

    /// - Tag: PerformAction
    func application(_ application: UIApplication, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
        // Alternatively, a shortcut item may be passed in through this delegate method if the app was
        // still in memory when the Home screen quick action was used. Again, store it for processing.
        shortcutItemToProcess = shortcutItem
    }

    /// - Tag: DidBecomeActive
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Is there a shortcut item that has not yet been processed?
        if let shortcutItem = shortcutItemToProcess {
            // In this sample an alert is being shown to indicate that the action has been triggered,
            // but in real code the functionality for the quick action would be triggered.
            var message = "\(shortcutItem.type) triggered"
            if let name = shortcutItem.userInfo?["Name"] {
                message += " for \(name)"
            }
            let alertController = UIAlertController(title: "Quick Action", message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
            window?.rootViewController?.present(alertController, animated: true, completion: nil)

            // Reset the shorcut item so it's never processed twice.
            shortcutItemToProcess = nil
        }
    }

    /// - Tag: WillResignActive
    func applicationWillResignActive(_ application: UIApplication) {
        // Transform each favorite contact into a UIApplicationShortcutItem.
        application.shortcutItems = ContactsData.shared.favoriteContacts.map { contact -> UIApplicationShortcutItem in
            return UIApplicationShortcutItem(type: "FavoriteAction",
                                             localizedTitle: contact.name,
                                             localizedSubtitle: contact.email,
                                             icon: UIApplicationShortcutIcon(type: .contact),
                                             userInfo: contact.quickActionUserInfo)
        }
    }

}
