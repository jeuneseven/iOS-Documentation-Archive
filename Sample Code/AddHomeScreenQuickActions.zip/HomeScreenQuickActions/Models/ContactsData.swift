/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A class that provides a sample set of contact data.
*/

import Foundation

class ContactsData {

    /// Shared access to the sample data.

    static let shared = ContactsData()

    /// An sample set of contact data.

    var contacts = [
        Contact(name: "John Appleseed", email: "john-appleseed@mac.com", favorite: true),
        Contact(name: "Kate Bell", email: "kate-bell@mac.com", favorite: true),
        Contact(name: "Anna Haro", email: "anna-haro@mac.com", favorite: true),
        Contact(name: "Daniel Higgins Jr.", email: "d-higgins@mac.com", favorite: false),
        Contact(name: "Hank M. Zakroff", email: "hank-zakroff@mac.com", favorite: false)
    ]

    /// Returns all favorite contacts from the sample data.

    var favoriteContacts: [ Contact ] {
        return contacts.filter({ $0.favorite == true })
    }

}
