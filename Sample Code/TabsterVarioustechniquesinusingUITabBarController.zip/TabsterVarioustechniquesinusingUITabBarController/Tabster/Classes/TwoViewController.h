/*
 Copyright (C) 2018 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The view controller for page two.
 */

@import UIKit;

@interface TwoViewController : UITableViewController

@end
